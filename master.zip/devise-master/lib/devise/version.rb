module Devise
  VERSION = "3.4.1".freeze
end
