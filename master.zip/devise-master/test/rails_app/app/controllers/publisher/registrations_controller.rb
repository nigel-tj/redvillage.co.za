class Publisher::RegistrationsController < ApplicationController
end
